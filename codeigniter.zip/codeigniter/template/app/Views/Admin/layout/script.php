 <!-- latest jquery-->
 <script src="<?= base_url() ?>/assets/js/jquery-3.5.1.min.js"></script>
 <!-- Bootstrap js-->
 <script src="<?= base_url() ?>/assets/js/bootstrap/bootstrap.bundle.min.js"></script>
 <!-- feather icon js-->
 <script src="<?= base_url() ?>/assets/js/icons/feather-icon/feather.min.js"></script>
 <script src="<?= base_url() ?>/assets/js/icons/feather-icon/feather-icon.js"></script>
 <!-- scrollbar js-->
 <script src="<?= base_url() ?>/assets/js/scrollbar/simplebar.js"></script>
 <script src="<?= base_url() ?>/assets/js/scrollbar/custom.js"></script>
 <!-- Sidebar jquery-->
 <script src="<?= base_url() ?>/assets/js/config.js"></script>

 <!-- Plugins JS start-->

 <script src="<?= base_url() ?>/assets/js/sidebar-menu.js"></script>
 <script src="<?= base_url() ?>/assets/js/slick/slick.min.js"></script>
 <script src="<?= base_url() ?>/assets/js/slick/slick.js"></script>
 <script src="<?= base_url() ?>/assets/js/header-slick.js"></script>
 <script src="<?= base_url() ?>/assets/js/chart/apex-chart/apex-chart.js"></script>
 <script src="<?= base_url() ?>/assets/js/animation/wow/wow.min.js"></script>
 <script src="<?= base_url() ?>/assets/js/prism/prism.min.js"></script>

 <!-- include script & Plugins -->
 <?= $this->renderSection('script') ?>

 <!-- Theme js-->
 <script src="<?= base_url() ?>/assets/js/script.js"></script>
 <script src="<?= base_url() ?>/assets/js/theme-customizer/customizer.js"></script>
 <!-- login js-->
 <!-- Plugin used-->
 <script>new WOW().init();</script>
