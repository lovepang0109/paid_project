<?= $this->extend('Admin/layout/master') ?>

<?= $this->section('main-content') ?>
dsdss

<?= $this->endSection() ?>

<?= $this->section('script') ?>


<?= $this->endSection() ?>