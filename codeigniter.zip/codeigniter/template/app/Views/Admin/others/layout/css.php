<!-- font-awesome -->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>/assets/css/font-awesome.css">
<!-- ico-font-->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>/assets/css/vendors/icofont.css">
<!-- Themify icon-->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>/assets/css/vendors/themify.css">
<!-- Flag icon-->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>/assets/css/vendors/flag-icon.css">
<!-- Feather icon-->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>/assets/css/vendors/feather-icon.css">
<!-- Bootstrap css-->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>/assets/css/vendors/bootstrap.css">
<!-- App css-->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>/assets/css/style.css">
<link id="color" rel="stylesheet" href="<?=base_url()?>/assets/css/color-1.css" media="screen">
<!-- Responsive css-->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>/assets/css/responsive.css">

<!-- includes css  -->
<?= $this->renderSection('css-other') ?>