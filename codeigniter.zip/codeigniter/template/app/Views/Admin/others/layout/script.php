<!-- latest jquery-->
<script src="<?=base_url()?>/assets/js/jquery-3.5.1.min.js"></script>
<!-- Bootstrap js-->
<script src="<?=base_url()?>/assets/js/bootstrap/bootstrap.bundle.min.js"></script>
<!-- feather icon js-->
<script src="<?=base_url()?>/assets/js/icons/feather-icon/feather.min.js"></script>
<script src="<?=base_url()?>/assets/js/icons/feather-icon/feather-icon.js"></script>
<!-- scrollbar js-->
<!-- Sidebar jquery-->
<script src="<?=base_url()?>/assets/js/config.js"></script>
<!-- Theme js-->
<script src="<?=base_url()?>/assets/js/script.js"></script>
<!-- login js-->
<!-- Plugin used-->

<!-- include scripts -->
<?= $this->renderSection('script-other') ?>
