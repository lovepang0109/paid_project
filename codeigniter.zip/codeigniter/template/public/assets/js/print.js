"use strict";
function myFunction() {
    window.print();
}